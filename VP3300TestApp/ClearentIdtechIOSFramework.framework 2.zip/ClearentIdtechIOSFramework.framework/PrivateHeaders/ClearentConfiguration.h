//
//  ClearentConfiguration.h
//  ClearentIdtechIOSFramework
//
//  Created by David Higginbotham on 6/25/18.
//  Copyright © 2018 Clearent, L.L.C. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ClearentConfiguration : NSObject

    @property (assign, getter=isValid) BOOL valid;
    @property(nonatomic) NSDictionary *rawJson;
    @property(nonatomic) NSDictionary *contactAids;
    @property(nonatomic) NSDictionary *publicKeys;
    @property(nonatomic) NSDictionary *contactlessPublicKeys;
    @property(nonatomic) BOOL autoConfiguration;
    @property(nonatomic) BOOL contactlessAutoConfiguration;
    @property(nonatomic) NSDictionary *contactlessGroups;
    @property(nonatomic) NSArray *contactlessSupportedAids;
    @property(nonatomic) NSDictionary *contactlessAids;

    - (id) initWithJson: (NSDictionary*) rawJson;

@end
